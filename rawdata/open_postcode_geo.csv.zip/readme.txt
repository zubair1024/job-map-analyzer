Open Postcode Geo
=================

For documentation see:

https://www.getthedata.com/open-postcode-geo

For licensing see licence.txt